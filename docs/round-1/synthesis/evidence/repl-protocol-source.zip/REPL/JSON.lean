/-
Copyright (c) 2023 Scott Morrison. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Scott Morrison
-/
import Lean.Data.Json
import Lean.Message
import Lean.Elab.InfoTree.Main
import REPL.Lean.InfoTree.ToJson

open Lean Elab InfoTree

namespace REPL

structure CommandOptions where
  allTactics : Option Bool := none
  declarations: Option Bool := none
  rootGoals : Option Bool := none
  /--
  Should be "full", "tactics", "original", or "substantive".
  Anything else is ignored.
  -/
  infotree : Option String
  incrementality : Option Bool := none -- whether to use incremental mode optimization
  setOptions : Option Options := none

/-- Run Lean commands.
If `env = none`, starts a new session (in which you can use `import`).
If `env = some n`, builds on the existing environment `n`.
-/
structure Command extends CommandOptions where
  env : Option Nat
  cmd : String
deriving ToJson, FromJson

/-- Process a Lean file in a fresh environment if `env` is not provided. -/
structure File extends CommandOptions where
  env : Option Nat
  path : System.FilePath
deriving ToJson, FromJson

/--
Run a tactic in a proof state.
-/
structure ProofStep where
  proofState : Nat
  tactic : String
deriving ToJson, FromJson

/-- Line and column information for error messages and sorries. -/
structure Pos where
  line : Nat
  column : Nat
deriving ToJson, FromJson, BEq, Hashable

/-- Severity of a message. -/
inductive Severity
  | trace | info | warning | error
deriving ToJson, FromJson

/-- A Lean message. -/
structure Message where
  pos : Pos
  endPos : Option Pos
  severity : Severity
  data : String
deriving ToJson, FromJson

/-- Construct the JSON representation of a Lean message. -/
def Message.of (m : Lean.Message) : IO Message := do pure <|
  { pos := ⟨m.pos.line, m.pos.column⟩,
    endPos := m.endPos.map fun p => ⟨p.line, p.column⟩,
    severity := match m.severity with
    | .information => .info
    | .warning => .warning
    | .error => .error,
    data := (← m.data.toString).trimAscii.toString }

/-- A Lean `sorry`. -/
structure Sorry where
  pos : Pos
  endPos : Pos
  goal : String
  /--
  The index of the proof state at the sorry.
  You can use the `ProofStep` instruction to run a tactic at this state.
  -/
  proofState : Option Nat
deriving FromJson

instance : ToJson Sorry where
  toJson r := Json.mkObj <| .flatten [
    [("goal", r.goal)],
    [("proofState", toJson r.proofState)],
    if r.pos.line ≠ 0 then [("pos", toJson r.pos)] else [],
    if r.endPos.line ≠ 0 then [("endPos", toJson r.endPos)] else [],
  ]

/-- Construct the JSON representation of a Lean sorry. -/
def Sorry.of (goal : String) (pos endPos : Lean.Position) (proofState : Option Nat) : Sorry :=
  { pos := ⟨pos.line, pos.column⟩,
    endPos := ⟨endPos.line, endPos.column⟩,
    goal,
    proofState }

structure Tactic where
  pos : Pos
  endPos : Pos
  goals : String
  tactic : String
  proofState : Option Nat
  usedConstants : Array Name
deriving ToJson, FromJson

/-- Construct the JSON representation of a Lean tactic. -/
def Tactic.of (goals tactic : String) (pos endPos : Lean.Position) (proofState : Option Nat) (usedConstants : Array Name) : Tactic :=
  { pos := ⟨pos.line, pos.column⟩,
    endPos := ⟨endPos.line, endPos.column⟩,
    goals,
    tactic,
    proofState,
    usedConstants }

structure DocString where
  content : String
  range : Elab.Syntax.Range
deriving ToJson

/-- See `Lean.Elab.Modifiers` -/
structure DeclModifiers where
  docString : Option DocString := none
  visibility : String := "regular" -- "regular", "private", or "public"
  computeKind : String := "regular" -- "regular", "meta", or "noncomputable"
  recKind : String := "default" -- "default", "partial", or "nonrec"
  isProtected : Bool := false
  isUnsafe : Bool := false
  attributes : List String := []
deriving ToJson

structure DeclSignature where
  pp : String
  constants : Array Name
  range : Elab.Syntax.Range
deriving ToJson

structure BinderView where
  id   : Syntax
  type : Syntax
  binderInfo : String

instance : ToJson BinderView where
  toJson (bv : BinderView) : Json :=
    Json.mkObj [
      ("id", toString bv.id.prettyPrint),
      ("type", toString bv.type.prettyPrint),
      ("binderInfo", bv.binderInfo)
    ]

structure DeclBinders where
  pp : String
  groups : Array String
  map : Array BinderView
  range : Elab.Syntax.Range
deriving ToJson

structure DeclType where
  pp : String
  constants : Array Name
  range : Elab.Syntax.Range
deriving ToJson

structure DeclValue where
  pp : String
  constants : Array Name
  range : Elab.Syntax.Range
deriving ToJson

local instance : ToJson OpenDecl where
  toJson
  | .simple ns except => json%{
    simple: { «namespace»: $ns, except: $except }
  }
  | .explicit id declName => json%{
    rename: { name: $declName, as: $id }
  }

structure ScopeInfo where
  varDecls : Array String
  includeVars : Array Name
  omitVars : Array Name
  levelNames : Array Name
  currNamespace : Name
  openDecl : List OpenDecl
deriving ToJson

structure DeclarationInfo where
  pp: String
  range : Elab.Syntax.Range
  scope : ScopeInfo
  name : Name
  fullName : Name
  kind : String
  modifiers : DeclModifiers
  signature: DeclSignature
  binders : Option DeclBinders := none
  type : Option DeclType := none
  value : Option DeclValue := none
deriving ToJson

/--
A response to a Lean command.
`env` can be used in later calls, to build on the stored environment.
-/
structure CommandResponse where
  env : Nat
  messages : List Message := []
  sorries : List Sorry := []
  tactics : List Tactic := []
  declarations: List DeclarationInfo := []
  infotree : Option Json := none

def Json.nonemptyList [ToJson α] (k : String) : List α → List (String × Json)
  | [] => []
  | l  => [⟨k, toJson l⟩]

instance : ToJson CommandResponse where
  toJson r := Json.mkObj <| .flatten [
    [("env", r.env)],
    Json.nonemptyList "messages" r.messages,
    Json.nonemptyList "sorries" r.sorries,
    Json.nonemptyList "tactics" r.tactics,
    Json.nonemptyList "declarations" r.declarations,
    match r.infotree with | some j => [("infotree", j)] | none => []
  ]

/--
A response to a Lean tactic.
`proofState` can be used in later calls, to run further tactics.
-/
structure ProofStepResponse where
  proofState : Nat
  goals : List String
  messages : List Message := []
  sorries : List Sorry := []
  traces : List String
  proofStatus : String
deriving ToJson, FromJson

instance : ToJson ProofStepResponse where
  toJson r := Json.mkObj <| .flatten [
    [("proofState", r.proofState)],
    [("goals", toJson r.goals)],
    Json.nonemptyList "messages" r.messages,
    Json.nonemptyList "sorries" r.sorries,
    Json.nonemptyList "traces" r.traces,
    [("proofStatus", r.proofStatus)]
  ]

/-- Json wrapper for an error. -/
structure Error where
  message : String
deriving ToJson, FromJson

structure PickleEnvironment where
  env : Nat
  pickleTo : System.FilePath
deriving ToJson, FromJson

structure UnpickleEnvironment where
  unpickleEnvFrom : System.FilePath
deriving ToJson, FromJson

structure PickleProofState where
  proofState : Nat
  pickleTo : System.FilePath
deriving ToJson, FromJson

structure UnpickleProofState where
  unpickleProofStateFrom : System.FilePath
  env : Option Nat
deriving ToJson, FromJson

end REPL
