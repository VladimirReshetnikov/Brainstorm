#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error strata.tex
pdflatex -interaction=nonstopmode -halt-on-error strata.tex
pdflatex -interaction=nonstopmode -halt-on-error strata.tex
